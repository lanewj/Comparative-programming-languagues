# Modify these functions. Add helper functions if you wish.
# These functions must be O(1).
def numNonZeros2DTriangular(N):
	if N == 1:
	    return 1
	elif N==0:
	    return 0
	num = N*N
	num = num + N
	num = num / 2
	return num
# print(numNonZeros2DTriangular(0))
def access2DTriangular(N, row, col): 
	# return -1 if any parameters are nonsensical
	if row > col:
	    return -1
	x = (N * row)  - numNonZeros2DTriangular(row) + col
	return x
	
#print(access2DTriangular(4, 1, 1))
#print(access2DTriangular(8, 3, 7))